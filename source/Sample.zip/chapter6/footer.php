<div class="container-fluid footpart">
   <footer class="container">
    <div class="row">
      <div class="col-xs-3 col-xs-offset-1">
        <h2><i class="fa fa-phone"></i> 1800-6403</h2>
        <h5>8:00 AM ~ 6:00 PM (토,일 공휴일 휴무)</h5>
        <h5>이메일 help@ticketplace.net </h5>        
      </div>
      <div class="col-xs-8 rightside">
          <ul class="list-inline footlink">
            <li><a href="#">에듀티켓 소개 </a></li>
            <li><a href="#">이용안내</a></li>
            <li><a href="#">고객센터 </a></li>    
            <li>제휴문의:1899-1534 </li>           
          </ul>
          <ul class="list-unstyled copy-txt">
            <li>대표이사 : 한세진, 한준희 | 사업자 등록번호 : 145-87-00100  개인정보 관리 책임자 : 한세진 help@ticketplace.net</li>
            <li>  서울시 종로구 창경궁로 271-1 동양서림 401호 (주)티켓플레이스   Copyright 2015 @Ticketplace Inc.</li>
          </ul>  
      </div>
    </div>    
   </footer>
 </div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>  
<script src="js/backtotop.js"></script> 
<script src="js/sticky-header.js"></script> 
<script type="text/javascript">
      $(document).ready(function(){
         $('.navbar-default').stickMe(); 
      })
 </script>

</body>
</html>