[3, 2, 1].join(" is bigger than ");
// "3 is bigger than 2 is bigger than 1"
