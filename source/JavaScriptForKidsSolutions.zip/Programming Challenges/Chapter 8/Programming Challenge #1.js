var add = function (a, b) {
  return a + b;
};

var multiply = function (a, b) {
  return a * b;
};

add(multiply(36325, 9824), 777);
// 356857577
