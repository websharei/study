## Command Line Interface Tools for Windows
- CMD
- Powershell
- Git Bash

## Command List
- cd {Path}
- mkdir {Directories Name}
- touch {files Name}
- ls
- ls -a
- mv file rename-file
- mv directory rename-directory
- mv file directory/file
- vim {file}
- clear
- exit
