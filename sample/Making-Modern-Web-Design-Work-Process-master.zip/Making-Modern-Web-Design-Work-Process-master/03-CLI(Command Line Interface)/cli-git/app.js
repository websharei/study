(function(global){
	if (!global.console) {
		global.alert('console을 사용할 수 없습니다.');
	}
})(window);