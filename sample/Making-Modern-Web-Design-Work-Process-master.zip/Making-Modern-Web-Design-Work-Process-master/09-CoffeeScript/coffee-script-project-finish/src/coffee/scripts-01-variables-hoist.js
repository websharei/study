# CoffeeScript 변수(Variables) 처리
jade = 'HTML 템플릿'
sass = 'CSS 프리프로세서'
coffee = 'Javascript 컴파일러'