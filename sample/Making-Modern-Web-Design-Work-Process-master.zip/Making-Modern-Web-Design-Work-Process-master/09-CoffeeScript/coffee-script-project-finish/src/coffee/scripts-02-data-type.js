### Javascript 복합 데이터형 ###
# 객체(Object)
book = 
	name: '만들면서 배우는 모던 웹 사이트 제작'
	publication: 2015
	publisher: '한빛미디어'
	author: '야무'

# 함수(Function)
fn = ->
fnc = ()->

#배열(Array)
arr = [null, 0, false]


### Javascript 기본 데이터형 ###
#숫자(Number)
num = 9 
#문자(String)
str = '야무'
#불린(Boolean)
boo = !false