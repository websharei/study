/*! yamoo9.net @ 2014 
	
	아래 코드를 복사해서 Emmet.sublime-settings - User 파일에 붙여넣습니다.
	
	"extensions_path": "c://emmet",
	"preferences": {
		"lorem.defaultLang": "ko"
	}

 */
emmet.require('generator/lorem').addLang('ko', '야무 한글 로렘입숨 더미텍스트 - 보기만 해도 찬란한 그대 젊음의 청춘 세상을 씩씩하게 만들 사명으로 하루를 엮어가는 너 청춘 피어나는 꽃처럼 눈부신 햇볕처럼 어디에나 빛나는 청춘아 가슴을 설레게 하고 장엄한 숨소리가 쿵쿵대는 청춘의 심장 고동소리 흐르는 땀 소리 숨죽여도 다 들리는 내일의 소리 티셔츠 운동화도 거추장스런 너 청춘 너야말로 꽃보다 아름답다 쉬지 않고 설레는 청춘아! 실수조차도 아름다운 너 청춘아!');