var yamoo9={};
// console.log(typeof yamoo9);

// 파일 이름 출력
console.log(__filename);
// 디렉토리 이름 출력
console.log(__dirname);