(function(global, undefined){
	'use strict';
})(window);