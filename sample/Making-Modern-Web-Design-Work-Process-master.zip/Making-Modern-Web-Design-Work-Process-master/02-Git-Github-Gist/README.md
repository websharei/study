##모던 웹 디자인 워크프로세스 - Git & GitHub 편

1. Git 설치
2. GitHub for Windows 애플리케이션 설치
3. GitHub 가입 및 애플리케이션에 연결
4. GitHub 저장소(Repository) 생성
5. 프로젝트 샘플 파일 추가(Add) & 커밋(Commit)
6. GitHub 저장소에 퍼블리싱(Publising: push)
7. 등록한 이메일 주소 검증(Verifying)
8. READ.md 파일 생성
9. 로컬 컴퓨터 Git 폴더의 READ.md 파일 수정
10. GitHub for Windows 애플리케이션을 통해 커밋(Commit)하고 푸시(Push)
