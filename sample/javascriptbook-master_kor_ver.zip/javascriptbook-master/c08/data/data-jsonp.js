showEvents({
  "events": [
    {
      "location": "샌프란시스코, CA",
      "date": "5월 1일",
      "map": "img/map-ca.png"
    },
    {
      "location": "오스틴, TX",
      "date": "5월 15일",
      "map": "img/map-tx.png"
    },
    {
      "location": "뉴욕, NY",
      "date": "5월 30일",
      "map": "img/map-ny.png"
    }
  ]
});