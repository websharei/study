// JavaScript Document

jQuery.fn.bgColor = function(color){
	$(this).css("background-color",color);
	return this;
}
